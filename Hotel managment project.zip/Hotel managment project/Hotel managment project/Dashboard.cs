﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;



namespace Hotel_managment_project
{
    public partial class Dashboard : Form
    {
        string path = @"Data Source=DESKTOP-02CDG87\SQLEXPRESS01;Initial Catalog=hotel_managment;Integrated Security=True;";
        SqlConnection conn;
        SqlCommand cmd;
        string username;

        private string loggedInUsername;


        public Dashboard(string username)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            conn = new SqlConnection(path);
            UpdateAdminCount();
            UpdateCustomerCount();
            UpdateStaffCount();
            BookCount();
            FreeCount();
            TotalCount();
            loggedInUsername = username;
            DisplayLoggedInUsername();
            LoadTimeFilter(); // Load the time filter options and chart data


        }

        private void DisplayLoggedInUsername()
        {
            // Set the label text to the logged-in username
            dlogname.Text = loggedInUsername;
        }

        public void loadform(object Form)
        {
            if (this.mainPanel.Controls.Count > 0)
                this.mainPanel.Controls.Clear();
            Form f = Form as Form;
            f.TopLevel = false;
            f.Dock = DockStyle.Fill;
            this.mainPanel.Controls.Add(f);
            this.mainPanel.Tag = f;
            f.Show();

        }



        private void adm_Click(object sender, EventArgs e)
        {
            loadform(new Admin(loggedInUsername));

        }

        private void custom_Click(object sender, EventArgs e)
        {
            loadform(new Customer(loggedInUsername));
        }

        private void staf_Click(object sender, EventArgs e)
        {
            loadform(new Staff(loggedInUsername));
        }

        private void book_Click(object sender, EventArgs e)
        {
            loadform(new Booking(loggedInUsername));
        }


        private void dashh_Click(object sender, EventArgs e)
        {
            loadform(new Dashboard(loggedInUsername));
        }



        private void dashClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void outlog_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do you want to Log Out?", "Log Out", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                this.Hide();
                Login login = new Login();
                login.ShowDialog();
                this.Show();
            }
            else if (result == DialogResult.No)
            {
                loadform(new Dashboard(username));
            }

        }


        private void UpdateAdminCount() // Method to fetch and display the count  
        {
            try
            {
                using (conn = new SqlConnection(path))
                {
                    using (cmd = new SqlCommand("SELECT COUNT(*) FROM admin", conn))
                    {
                        conn.Open();
                        int adminCount = (int)cmd.ExecuteScalar();
                        conn.Close();

                        // Update label's text  
                        admincount.Text = $"{adminCount}";
                        //cust.Maximum = adminCount;  
                        adminpro.Value = adminCount;     
                    
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error counting Admins: " + ex.Message);
            }
        }

        private void UpdateCustomerCount() // Method to fetch and display the count  
        {
            try
            {
                using (conn = new SqlConnection(path))
                {
                    using (cmd = new SqlCommand("SELECT COUNT(*) FROM customer", conn))
                    {
                        conn.Open();
                        int customerCount = (int)cmd.ExecuteScalar();
                        conn.Close();

                        // Update label's text  
                        ccount.Text = $"{customerCount}";
                        //cust.Maximum = adminCount;  
                        cust.Value = customerCount;

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error counting Coustomer: " + ex.Message);
            }
        }

        private void UpdateStaffCount() // Method to fetch and display the count  
        {
            try
            {
                using (conn = new SqlConnection(path))
                {
                    using (cmd = new SqlCommand("SELECT COUNT(*) FROM staff", conn))
                    {
                        conn.Open();
                        int staffCount = (int)cmd.ExecuteScalar();
                        conn.Close();

                        // Update label's text  
                        scount.Text = $"{staffCount}";
                        //cust.Maximum = adminCount;  
                        sta.Value = staffCount;

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error counting Staff: " + ex.Message);
            }
        }

        private void BookCount() // Method to fetch and display the count  
        {
            const int totalRooms = 19; // Set total number of rooms  
            try
            {
                using (conn = new SqlConnection(path))
                {
                    using (cmd = new SqlCommand("SELECT COUNT(*) FROM booking", conn))
                    {
                        conn.Open();
                        int bookCount = (int)cmd.ExecuteScalar();
                        conn.Close();

                        // Update label's text  
                        broom.Text = $"{bookCount}";

                        // Update progress bar  
                        bookroom.Maximum = totalRooms; // Set the maximum value of progress bar to total rooms  
                        bookroom.Value = bookCount;     // Set the current value of progress bar to the count of booked rooms  
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error counting Booking: " + ex.Message);
            }
        }

        private void FreeCount() // Method to fetch and display the count  
        {
            const int totalRooms = 19; // Set total number of rooms  
            try
            {
                using (conn = new SqlConnection(path))
                {
                    using (cmd = new SqlCommand("SELECT COUNT(*) FROM room WHERE IsAvailable = 1", conn))
                    {
                        conn.Open();
                        int freeCount = (int)cmd.ExecuteScalar();
                        conn.Close();

                        // Update label's text  
                        froom.Text = $"{freeCount}";

                        // Update progress bar  
                        freeroom.Maximum = totalRooms; // Set the maximum value of progress bar to total rooms  
                        freeroom.Value = freeCount;     // Set the current value of progress bar to the count of available rooms  
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error counting Free Room: " + ex.Message);
            }
        }

        private void TotalCount() // Method to fetch and display the count  
        {
            try
            {
                using (conn = new SqlConnection(path))
                {
                    using (cmd = new SqlCommand("SELECT COUNT(*) FROM room", conn))
                    {
                        conn.Open();
                        int totCount = (int)cmd.ExecuteScalar();
                        conn.Close();

                        // Update label's text  
                        troom.Text = $"{totCount}";

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error counting Rooms: " + ex.Message);
            }
        }

        private void DashLogName() // Method to fetch and display the count  
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(path))
                {
                    using (SqlCommand cmd = new SqlCommand("SELECT username FROM admin where username == username", conn))
                    {
                        conn.Open();
                        string adminname = (string)cmd.ExecuteScalar();
                        conn.Close();

                        // Update label's text  
                       dlogname.Text = adminname;

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error name of Admins: " + ex.Message);
            }
        }


        private void GenerateBookingReport()
        {
            try
            {
                using (conn = new SqlConnection(path))
                {
                    string query = "SELECT * FROM Booking";
                    using (cmd = new SqlCommand(query, conn))
                    {
                        conn.Open();
                        SqlDataReader reader = cmd.ExecuteReader();

                        if (reader.HasRows)
                        {
                            // Set the file path
                            string filePath = @"F:\BookingReport.txt"; // Change this to your desired location

                            using (StreamWriter writer = new StreamWriter(filePath))
                            {
                                // Write headers
                                writer.WriteLine("id\t\tadult\tchild\tnight\tbedroom\trooms\tcheckin\t\tcheckout");

                                // Write data
                                while (reader.Read())
                                {
                                    writer.WriteLine(
                                        $"{reader["id"]}\t" +
                                        $"{reader["adult"]}\t" +
                                        $"{reader["child"]}\t"+
                                        $"{reader["night"]}\t" +
                                        $"{reader["bedroom"]}\t" +
                                        $"{reader["rooms"]}\t" +
                                        $"{Convert.ToDateTime(reader["checkin"]).ToString("yyyy-MM-dd")}\t" +
                                        $"{Convert.ToDateTime(reader["checkout"]).ToString("yyyy-MM-dd")}\t" );
                                }
                            }

                            MessageBox.Show($"Booking report generated successfully at {filePath}", "Report Generated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("No bookings found to generate the report.", "No Data", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }

                        reader.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error generating report: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            GenerateBookingReport();
        }


        private void dateDropdown_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadChartData();

        }

        private void LoadTimeFilter()
        {
            dateDropdown.Items.AddRange(new string[] { "Today", "This Week", "This Month" });
            dateDropdown.SelectedIndex = 0; // Default to 'Today'
            dateDropdown.SelectedIndexChanged += dateDropdown_SelectedIndexChanged;
            LoadChartData();
        }


        private string GetQueryForTimeFilter(string timeFilter)
        {
            string dateCondition = "";

            switch (timeFilter)
            {
                case "Today":
                    dateCondition = "CONVERT(date, checkin) = CONVERT(date, GETDATE())";
                    break;
                case "This Week":
                    dateCondition = "DATEPART(week, checkin) = DATEPART(week, GETDATE()) AND YEAR(checkin) = YEAR(GETDATE())";
                    break;
                case "This Month":
                    dateCondition = "MONTH(checkin) = MONTH(GETDATE()) AND YEAR(checkin) = YEAR(GETDATE())";
                    break;
            }

            string query = $@"
        SELECT 
            SUM(adult) AS TotalAdults,
            SUM(child) AS TotalChildren,
            COUNT(*) AS TotalBookings
        FROM 
            booking
        WHERE 
            {dateCondition}";

            return query;
        }



        private void LoadChartData()
        {
            string timeFilter = dateDropdown.SelectedItem.ToString();
            string query = GetQueryForTimeFilter(timeFilter);

            DataTable dataTable = GetData(query);

            // Debug: Output the results to check if they're correct
            if (dataTable.Rows.Count > 0)
            {
                DataRow row = dataTable.Rows[0];
            }

            DisplayChart(dataTable);
        }

        private void DisplayChart(DataTable dataTable)
        {
            bookingChart.Series.Clear();
            bookingChart.Titles.Clear();

            bookingChart.Titles.Add("Booking Data");

            Series series = new Series
            {
                Name = "BookingData",
                IsValueShownAsLabel = true,
                ChartType = SeriesChartType.Pie
            };

            bookingChart.Series.Add(series);

            if (dataTable.Rows.Count > 0)
            {
                DataRow row = dataTable.Rows[0];

                series.Points.AddXY("Adults", row["TotalAdults"]);
                series.Points.AddXY("Children", row["TotalChildren"]);
                series.Points.AddXY("Bookings", row["TotalBookings"]);
            }
        }

        private DataTable GetData(string query)
        {
            DataTable dataTable = new DataTable();

            try
            {
                using (conn = new SqlConnection(path))
                {
                    using (cmd = new SqlCommand(query, conn))
                    {
                        conn.Open();
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                        adapter.Fill(dataTable);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error fetching data: " + ex.Message);
            }

            return dataTable;
        }


    }


}

