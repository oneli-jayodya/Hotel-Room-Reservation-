﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.AxHost;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using System.Xml;

namespace Hotel_managment_project
{
    public partial class Customer : Form
    {
        private string logInUsername;

        string path = @"Data Source=DESKTOP-02CDG87\SQLEXPRESS01;Initial Catalog=hotel_managment;Integrated Security=True;";
        SqlConnection conn;
        SqlCommand cmd;

        string name;
        string address;
        string gender;
        int mobile;
        string id;
        string dob;

        public Customer(string username)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            conn = new SqlConnection(path);
            Display();
            logInUsername = username;
            DisplayLogUsername();
        }

        private void DisplayLogUsername()
        {
            clogname.Text = logInUsername;
        }

        private void cusClose_click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //display customer details
        public void Display()
        {
            try
            {
                conn.Open();
                cmd = new SqlCommand("select * from customer", conn);
                cmd.ExecuteNonQuery();
                conn.Close();
                SqlDataAdapter sd = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sd.Fill(dt);
                customerview.DataSource = dt;
                

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        //insert customer details
        private void cinsert_Click(object sender, EventArgs e)
        {
                name = cname.Text;
                string mobileStr = cmobile.Text.TrimStart('0'); 
                dob = cdate.Value.ToString("yyyy-MM-dd");
                address = caddress.Text;
                id = cid.Text;

                if (cmale.Checked)
                {
                    gender = "Male";
                }
                else if (cfemale.Checked)
                {
                    gender = "Female";
                }

                if (System.Text.RegularExpressions.Regex.IsMatch(name, "[0-9~`!@#$%^&*()-+=|\\{}':;,.<>?]"))
                {
                    MessageBox.Show("Name should not contain numbers or symbols.");
                    return;
                }

                if (!System.Text.RegularExpressions.Regex.IsMatch(mobileStr, @"^\d{9}$")) 
                {
                    MessageBox.Show("Mobile number should be a 10-digit number starting with 07.");
                    return;
                }


                mobile = Convert.ToInt32(mobileStr);


                // Confirm update
                DialogResult confirmResult = MessageBox.Show(
                    "Are you sure you want to insert this record?",
                    "Confirm Delete",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question
                );

                if (confirmResult == DialogResult.Yes)
                {
                try
                {
                    conn.Open();

                    // Check if the ID already exists  
                    using (cmd = new SqlCommand("SELECT COUNT(*) FROM customer WHERE id = @id", conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        int idExists = (int)cmd.ExecuteScalar();

                        if (idExists > 0)
                        {
                            MessageBox.Show("This ID is already registered!");
                            return; // Exit the method if ID exists  
                        }
                    }

                    cmd = new SqlCommand("INSERT INTO customer (name, address, id, gender, birth, mobile) VALUES (@name, @address, @id, @gender, @birth, @mobile)", conn);

                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@address", address);
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@gender", gender);
                    cmd.Parameters.AddWithValue("@birth", dob);
                    cmd.Parameters.AddWithValue("@mobile", mobile);

                    cmd.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Registered Successfuly!!");
                    Display();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    conn.Close();
                }
            }

        }

        private void customerview_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = customerview.Rows[e.RowIndex];


                string mobileStr = row.Cells["mobile"].Value.ToString();
                if (int.TryParse(mobileStr.TrimStart('0'), out mobile))
                {
                    cname.Text = row.Cells["name"].Value.ToString();
                    cmobile.Text = mobileStr;
                    cdate.Value = (DateTime)row.Cells["birth"].Value;
                    caddress.Text = row.Cells["address"].Value.ToString();
                    cid.Text = row.Cells["id"].Value.ToString();

                    if (row.Cells["gender"].Value.ToString() == "Male")
                    {
                        cmale.Checked = true;
                        cfemale.Checked = false;
                    }
                    else
                    {
                        cfemale.Checked = true;
                        cmale.Checked = false;
                    }
                }
            }
            else
            {
                MessageBox.Show("Invalid cell selected.");
                
            }
        }

        private void cupdate_Click(object sender, EventArgs e)
        {
            if (customerview.CurrentCell != null && mobile != 0)
            {
                name = cname.Text;
                mobile = Convert.ToInt32(cmobile.Text.TrimStart('0'));
                dob = cdate.Value.ToString("yyyy-MM-dd");
                address = caddress.Text;
                id = cid.Text;

                if (cmale.Checked)
                {
                    gender = "Male";
                }
                else if (cfemale.Checked)
                {
                    gender = "Female";
                }

                // Confirm update
                DialogResult confirmResult = MessageBox.Show(
                    "Are you sure you want to update this record?",
                    "Confirm Update",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question
                );

                if (confirmResult == DialogResult.Yes)
                {
                    try
                    {
                        conn.Open();
                        SqlCommand cmd = new SqlCommand("UPDATE customer SET name = @name, address = @address, gender = @gender, birth = @birth, mobile = @mobile WHERE id = @id", conn);
                        cmd.Parameters.AddWithValue("@name", name);
                        cmd.Parameters.AddWithValue("@address", address);
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.Parameters.AddWithValue("@gender", gender);
                        cmd.Parameters.AddWithValue("@birth", dob);
                        cmd.Parameters.AddWithValue("@mobile", mobile);
                        cmd.ExecuteNonQuery();
                        conn.Close();
                        Display();
                        MessageBox.Show("Details Update.");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error updating record: " + ex.Message);
                    }
                }
                else
                {
                    MessageBox.Show("Select a record to update.");
                    conn.Close();
                }
            }
        }

        private void cdelete_Click(object sender, EventArgs e)
        {
            // Confirm delete
            DialogResult confirmResult = MessageBox.Show(
                "Are you sure you want to Delete this record?",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (confirmResult == DialogResult.Yes)
            {
                if (mobile != 0)
                {
                    cmd = new SqlCommand("DELETE FROM customer WHERE id = @id", conn);
                    cmd.Parameters.AddWithValue("@id", id);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();

                    MessageBox.Show("Record Deleted Successfully!");
                    Display();
                }
                else
                {
                    MessageBox.Show("Please Select a Record to Delete");
                    conn.Close();
                }
            }
        } 

        private void creset_Click(object sender, EventArgs e)
        {
            cname.Text = "";
            cmobile.Text = "";
            cid.Text = "";
            caddress.Text = "";
            searchc.Text = "";
            cmale.Checked = false;
            cfemale.Checked = false;
            cdate.Value = DateTime.Now;
            mobile = 0;
        }

        private void csearch_Click(object sender, EventArgs e)
        {
            string searchId = searchc.Text.Trim(); // Get the customer ID to search  

            if (string.IsNullOrWhiteSpace(searchId))
            {
                MessageBox.Show("Please enter a customer ID to search.");
                return;
            }

            // Clear previous results first  
            customerview.DataSource = null;
            customerview.Rows.Clear();

            try
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT name, address, id, gender, birth, mobile FROM customer WHERE id = @id", conn))
                {
                    cmd.Parameters.AddWithValue("@id", searchId);

                    SqlDataReader reader = cmd.ExecuteReader();
                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);

                    if (dataTable.Rows.Count > 0)
                    {
                        customerview.DataSource = dataTable;
                    }
                    else
                    {
                        MessageBox.Show("Customer not found!");
                        Display();
                    }
                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error fetching customer details: " + ex.Message);
                conn.Close();
            }
            
        }
    }
}
