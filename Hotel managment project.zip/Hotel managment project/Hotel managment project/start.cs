﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotel_managment_project
{
    public partial class start : Form
    {
        public start()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void start_Load(object sender, EventArgs e)
        {

        }

        private void start_close(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void startup_Click(object sender, EventArgs e)
        {

            //hide this form and open other form
            this.Hide();
            Login log = new Login();
            log.ShowDialog();

            //come back to the privous page when closing
            // log =null;
            //this.Show();
        }
    }
}
