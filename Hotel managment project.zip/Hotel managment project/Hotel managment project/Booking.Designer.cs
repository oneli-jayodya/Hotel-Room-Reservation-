﻿using System;

namespace Hotel_managment_project
{
    partial class Booking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Booking));
            this.label1 = new System.Windows.Forms.Label();
            this.resetb = new System.Windows.Forms.Button();
            this.deleteb = new System.Windows.Forms.Button();
            this.insertb = new System.Windows.Forms.Button();
            this.updateb = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.searchb = new System.Windows.Forms.TextBox();
            this.bookview = new System.Windows.Forms.DataGridView();
            this.checkin = new System.Windows.Forms.DateTimePicker();
            this.family = new System.Windows.Forms.RadioButton();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.blogname = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.adult = new System.Windows.Forms.ComboBox();
            this.child = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.doubleroom = new System.Windows.Forms.RadioButton();
            this.rooms = new System.Windows.Forms.ComboBox();
            this.checkout = new System.Windows.Forms.DateTimePicker();
            this.label18 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.single = new System.Windows.Forms.RadioButton();
            this.idcombo = new System.Windows.Forms.ComboBox();
            this.bnight = new System.Windows.Forms.TextBox();
            this.booksearch = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.bookClose = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.bookview)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(20, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(374, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "BOOKING/RESERVATION";
            // 
            // resetb
            // 
            this.resetb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(152)))), ((int)(((byte)(228)))));
            this.resetb.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resetb.Location = new System.Drawing.Point(888, 651);
            this.resetb.Name = "resetb";
            this.resetb.Size = new System.Drawing.Size(161, 52);
            this.resetb.TabIndex = 87;
            this.resetb.Text = "RESET";
            this.resetb.UseVisualStyleBackColor = false;
            this.resetb.Click += new System.EventHandler(this.resetb_Click);
            // 
            // deleteb
            // 
            this.deleteb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.deleteb.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteb.Location = new System.Drawing.Point(696, 651);
            this.deleteb.Name = "deleteb";
            this.deleteb.Size = new System.Drawing.Size(161, 52);
            this.deleteb.TabIndex = 86;
            this.deleteb.Text = "DELETE";
            this.deleteb.UseVisualStyleBackColor = false;
            this.deleteb.Click += new System.EventHandler(this.deleteb_Click);
            // 
            // insertb
            // 
            this.insertb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(241)))), ((int)(((byte)(189)))));
            this.insertb.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.insertb.Location = new System.Drawing.Point(303, 651);
            this.insertb.Name = "insertb";
            this.insertb.Size = new System.Drawing.Size(161, 52);
            this.insertb.TabIndex = 84;
            this.insertb.Text = "INSERT";
            this.insertb.UseVisualStyleBackColor = false;
            this.insertb.Click += new System.EventHandler(this.insertb_Click);
            // 
            // updateb
            // 
            this.updateb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(231)))), ((int)(((byte)(113)))));
            this.updateb.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateb.Location = new System.Drawing.Point(503, 651);
            this.updateb.Name = "updateb";
            this.updateb.Size = new System.Drawing.Size(161, 52);
            this.updateb.TabIndex = 85;
            this.updateb.Text = "UPDATE";
            this.updateb.UseVisualStyleBackColor = false;
            this.updateb.Click += new System.EventHandler(this.updateb_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Impact", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(747, 214);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(74, 25);
            this.label13.TabIndex = 83;
            this.label13.Text = "Enter ID";
            // 
            // searchb
            // 
            this.searchb.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchb.Location = new System.Drawing.Point(839, 210);
            this.searchb.Name = "searchb";
            this.searchb.Size = new System.Drawing.Size(233, 32);
            this.searchb.TabIndex = 82;
            // 
            // bookview
            // 
            this.bookview.BackgroundColor = System.Drawing.SystemColors.InactiveBorder;
            this.bookview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bookview.Location = new System.Drawing.Point(739, 260);
            this.bookview.Name = "bookview";
            this.bookview.RowHeadersWidth = 51;
            this.bookview.RowTemplate.Height = 24;
            this.bookview.Size = new System.Drawing.Size(417, 362);
            this.bookview.TabIndex = 81;
            this.bookview.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.bookview_CellContentClick);
            // 
            // checkin
            // 
            this.checkin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkin.Location = new System.Drawing.Point(381, 499);
            this.checkin.Name = "checkin";
            this.checkin.Size = new System.Drawing.Size(290, 27);
            this.checkin.TabIndex = 80;
            // 
            // family
            // 
            this.family.AutoSize = true;
            this.family.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.family.Location = new System.Drawing.Point(604, 396);
            this.family.Name = "family";
            this.family.Size = new System.Drawing.Size(92, 32);
            this.family.TabIndex = 79;
            this.family.TabStop = true;
            this.family.Text = "Family";
            this.family.UseVisualStyleBackColor = true;
            this.family.CheckedChanged += new System.EventHandler(this.family_CheckedChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(229, 498);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(91, 28);
            this.label12.TabIndex = 77;
            this.label12.Text = "Check-In";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(229, 400);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(102, 28);
            this.label11.TabIndex = 76;
            this.label11.Text = "BedRoom";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(229, 445);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(75, 28);
            this.label8.TabIndex = 72;
            this.label8.Text = "Rooms";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(229, 289);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(71, 28);
            this.label7.TabIndex = 70;
            this.label7.Text = "Adults";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(211)))), ((int)(((byte)(246)))));
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(217, 124);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(940, 46);
            this.panel2.TabIndex = 67;
            // 
            // blogname
            // 
            this.blogname.AutoSize = true;
            this.blogname.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.blogname.Location = new System.Drawing.Point(981, 60);
            this.blogname.Name = "blogname";
            this.blogname.Size = new System.Drawing.Size(57, 24);
            this.blogname.TabIndex = 66;
            this.blogname.Text = "name";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1079, 44);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(78, 69);
            this.pictureBox2.TabIndex = 65;
            this.pictureBox2.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(293, 73);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(236, 22);
            this.label4.TabIndex = 64;
            this.label4.Text = "spend your time and relaxation";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(292, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 28);
            this.label2.TabIndex = 63;
            this.label2.Text = "HOTEL MISUKI";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(217, 44);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(87, 83);
            this.pictureBox1.TabIndex = 62;
            this.pictureBox1.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(229, 231);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 28);
            this.label6.TabIndex = 68;
            this.label6.Text = "ID No";
            // 
            // adult
            // 
            this.adult.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adult.FormattingEnabled = true;
            this.adult.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "0"});
            this.adult.Location = new System.Drawing.Point(382, 292);
            this.adult.Name = "adult";
            this.adult.Size = new System.Drawing.Size(89, 28);
            this.adult.TabIndex = 88;
            // 
            // child
            // 
            this.child.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.child.FormattingEnabled = true;
            this.child.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "0"});
            this.child.Location = new System.Drawing.Point(582, 289);
            this.child.Name = "child";
            this.child.Size = new System.Drawing.Size(89, 28);
            this.child.TabIndex = 90;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(505, 289);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 28);
            this.label3.TabIndex = 89;
            this.label3.Text = "Child";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(229, 348);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(72, 28);
            this.label9.TabIndex = 91;
            this.label9.Text = "Nights";
            // 
            // doubleroom
            // 
            this.doubleroom.AutoSize = true;
            this.doubleroom.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.doubleroom.Location = new System.Drawing.Point(485, 396);
            this.doubleroom.Name = "doubleroom";
            this.doubleroom.Size = new System.Drawing.Size(99, 32);
            this.doubleroom.TabIndex = 93;
            this.doubleroom.TabStop = true;
            this.doubleroom.Text = "Double";
            this.doubleroom.UseVisualStyleBackColor = true;
            this.doubleroom.CheckedChanged += new System.EventHandler(this.doubleroom_CheckedChanged);
            // 
            // rooms
            // 
            this.rooms.DropDownHeight = 60;
            this.rooms.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rooms.FormattingEnabled = true;
            this.rooms.IntegralHeight = false;
            this.rooms.Location = new System.Drawing.Point(382, 445);
            this.rooms.Name = "rooms";
            this.rooms.Size = new System.Drawing.Size(181, 28);
            this.rooms.TabIndex = 94;
            // 
            // checkout
            // 
            this.checkout.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkout.Location = new System.Drawing.Point(381, 547);
            this.checkout.Name = "checkout";
            this.checkout.Size = new System.Drawing.Size(290, 27);
            this.checkout.TabIndex = 96;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(229, 546);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(108, 28);
            this.label18.TabIndex = 95;
            this.label18.Text = "Check-Out";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.single);
            this.panel1.Controls.Add(this.idcombo);
            this.panel1.Controls.Add(this.bnight);
            this.panel1.Controls.Add(this.booksearch);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.checkout);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.rooms);
            this.panel1.Controls.Add(this.doubleroom);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.child);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.adult);
            this.panel1.Controls.Add(this.resetb);
            this.panel1.Controls.Add(this.deleteb);
            this.panel1.Controls.Add(this.insertb);
            this.panel1.Controls.Add(this.updateb);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.searchb);
            this.panel1.Controls.Add(this.bookview);
            this.panel1.Controls.Add(this.checkin);
            this.panel1.Controls.Add(this.family);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.blogname);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1186, 719);
            this.panel1.TabIndex = 101;
            // 
            // single
            // 
            this.single.AutoSize = true;
            this.single.Font = new System.Drawing.Font("Calibri", 13.8F);
            this.single.Location = new System.Drawing.Point(384, 396);
            this.single.Name = "single";
            this.single.Size = new System.Drawing.Size(88, 32);
            this.single.TabIndex = 107;
            this.single.TabStop = true;
            this.single.Text = "Single";
            this.single.UseVisualStyleBackColor = true;
            this.single.CheckedChanged += new System.EventHandler(this.single_CheckedChanged);
            // 
            // idcombo
            // 
            this.idcombo.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idcombo.FormattingEnabled = true;
            this.idcombo.Items.AddRange(new object[] {
            "....."});
            this.idcombo.Location = new System.Drawing.Point(377, 232);
            this.idcombo.Name = "idcombo";
            this.idcombo.Size = new System.Drawing.Size(294, 33);
            this.idcombo.TabIndex = 104;
            // 
            // bnight
            // 
            this.bnight.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bnight.Location = new System.Drawing.Point(384, 348);
            this.bnight.Name = "bnight";
            this.bnight.Size = new System.Drawing.Size(87, 32);
            this.bnight.TabIndex = 103;
            // 
            // booksearch
            // 
            this.booksearch.BackColor = System.Drawing.SystemColors.Highlight;
            this.booksearch.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.booksearch.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.booksearch.Location = new System.Drawing.Point(1080, 208);
            this.booksearch.Name = "booksearch";
            this.booksearch.Size = new System.Drawing.Size(76, 34);
            this.booksearch.TabIndex = 102;
            this.booksearch.Text = "Search";
            this.booksearch.UseVisualStyleBackColor = false;
            this.booksearch.Click += new System.EventHandler(this.booksearch_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(211)))), ((int)(((byte)(246)))));
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.bookClose);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1184, 31);
            this.panel3.TabIndex = 101;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(528, 1);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(106, 28);
            this.label14.TabIndex = 102;
            this.label14.Text = "BOOKING";
            this.label14.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // bookClose
            // 
            this.bookClose.BackColor = System.Drawing.Color.Transparent;
            this.bookClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bookClose.ForeColor = System.Drawing.Color.Transparent;
            this.bookClose.Image = ((System.Drawing.Image)(resources.GetObject("bookClose.Image")));
            this.bookClose.Location = new System.Drawing.Point(1145, 0);
            this.bookClose.Name = "bookClose";
            this.bookClose.Size = new System.Drawing.Size(36, 29);
            this.bookClose.TabIndex = 0;
            this.bookClose.UseVisualStyleBackColor = false;
            this.bookClose.Click += new System.EventHandler(this.bookClose_Click);
            // 
            // Booking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1186, 719);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Booking";
            this.Text = "Booking";
            ((System.ComponentModel.ISupportInitialize)(this.bookview)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        private void customb_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void outb_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void adminb_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void bookb_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void dashb_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void staffb_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button resetb;
        private System.Windows.Forms.Button deleteb;
        private System.Windows.Forms.Button insertb;
        private System.Windows.Forms.Button updateb;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox searchb;
        private System.Windows.Forms.DataGridView bookview;
        private System.Windows.Forms.DateTimePicker checkin;
        private System.Windows.Forms.RadioButton family;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label blogname;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox adult;
        private System.Windows.Forms.ComboBox child;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton doubleroom;
        private System.Windows.Forms.ComboBox rooms;
        private System.Windows.Forms.DateTimePicker checkout;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button bookClose;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button booksearch;
        private System.Windows.Forms.TextBox bnight;
        private System.Windows.Forms.ComboBox idcombo;
        private System.Windows.Forms.RadioButton single;
    }
}