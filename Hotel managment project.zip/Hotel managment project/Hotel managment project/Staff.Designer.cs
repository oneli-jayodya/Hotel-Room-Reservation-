﻿namespace Hotel_managment_project
{
    partial class Staff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Staff));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.slogname = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.sname = new System.Windows.Forms.TextBox();
            this.saddress = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.sid = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.sposition = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.smobile = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.smale = new System.Windows.Forms.RadioButton();
            this.sfemale = new System.Windows.Forms.RadioButton();
            this.sdate = new System.Windows.Forms.DateTimePicker();
            this.staffview = new System.Windows.Forms.DataGridView();
            this.searchs = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.delete = new System.Windows.Forms.Button();
            this.update = new System.Windows.Forms.Button();
            this.insert = new System.Windows.Forms.Button();
            this.reset = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.ssearch = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.staffClose = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.staffview)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(219, 45);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(87, 83);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(294, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 28);
            this.label2.TabIndex = 4;
            this.label2.Text = "HOTEL MISUKI";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(295, 74);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(236, 22);
            this.label4.TabIndex = 6;
            this.label4.Text = "spend your time and relaxation";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1081, 45);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(78, 69);
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            // 
            // slogname
            // 
            this.slogname.AutoSize = true;
            this.slogname.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.slogname.Location = new System.Drawing.Point(994, 49);
            this.slogname.Name = "slogname";
            this.slogname.Size = new System.Drawing.Size(57, 24);
            this.slogname.TabIndex = 8;
            this.slogname.Text = "name";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(211)))), ((int)(((byte)(246)))));
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(219, 131);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(940, 48);
            this.panel2.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(20, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(345, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "STAFF REGISTRATION";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(579, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 28);
            this.label6.TabIndex = 10;
            this.label6.Text = "STAFF";
            // 
            // sname
            // 
            this.sname.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sname.Location = new System.Drawing.Point(398, 225);
            this.sname.Name = "sname";
            this.sname.Size = new System.Drawing.Size(293, 32);
            this.sname.TabIndex = 11;
            // 
            // saddress
            // 
            this.saddress.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saddress.Location = new System.Drawing.Point(398, 276);
            this.saddress.Multiline = true;
            this.saddress.Name = "saddress";
            this.saddress.Size = new System.Drawing.Size(293, 84);
            this.saddress.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(254, 276);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 28);
            this.label7.TabIndex = 12;
            this.label7.Text = "Address";
            // 
            // sid
            // 
            this.sid.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sid.Location = new System.Drawing.Point(398, 382);
            this.sid.Name = "sid";
            this.sid.Size = new System.Drawing.Size(293, 32);
            this.sid.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(254, 382);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 28);
            this.label8.TabIndex = 14;
            this.label8.Text = "ID No";
            // 
            // sposition
            // 
            this.sposition.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sposition.Location = new System.Drawing.Point(398, 594);
            this.sposition.Name = "sposition";
            this.sposition.Size = new System.Drawing.Size(290, 32);
            this.sposition.TabIndex = 17;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(253, 594);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(87, 28);
            this.label9.TabIndex = 16;
            this.label9.Text = "Position";
            // 
            // smobile
            // 
            this.smobile.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.smobile.Location = new System.Drawing.Point(398, 544);
            this.smobile.Name = "smobile";
            this.smobile.Size = new System.Drawing.Size(290, 32);
            this.smobile.TabIndex = 19;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(254, 548);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 28);
            this.label10.TabIndex = 18;
            this.label10.Text = "Mobile";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(254, 439);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(81, 28);
            this.label11.TabIndex = 20;
            this.label11.Text = "Gender";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(253, 493);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(131, 28);
            this.label12.TabIndex = 21;
            this.label12.Text = "Date of Birth";
            // 
            // smale
            // 
            this.smale.AutoSize = true;
            this.smale.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.smale.Location = new System.Drawing.Point(398, 435);
            this.smale.Name = "smale";
            this.smale.Size = new System.Drawing.Size(80, 32);
            this.smale.TabIndex = 22;
            this.smale.TabStop = true;
            this.smale.Text = "Male";
            this.smale.UseVisualStyleBackColor = true;
            // 
            // sfemale
            // 
            this.sfemale.AutoSize = true;
            this.sfemale.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sfemale.Location = new System.Drawing.Point(548, 435);
            this.sfemale.Name = "sfemale";
            this.sfemale.Size = new System.Drawing.Size(100, 32);
            this.sfemale.TabIndex = 23;
            this.sfemale.TabStop = true;
            this.sfemale.Text = "Female";
            this.sfemale.UseVisualStyleBackColor = true;
            // 
            // sdate
            // 
            this.sdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sdate.Location = new System.Drawing.Point(398, 494);
            this.sdate.Name = "sdate";
            this.sdate.Size = new System.Drawing.Size(290, 27);
            this.sdate.TabIndex = 24;
            // 
            // staffview
            // 
            this.staffview.BackgroundColor = System.Drawing.SystemColors.InactiveBorder;
            this.staffview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.staffview.Location = new System.Drawing.Point(741, 263);
            this.staffview.Name = "staffview";
            this.staffview.RowHeadersWidth = 51;
            this.staffview.RowTemplate.Height = 24;
            this.staffview.Size = new System.Drawing.Size(417, 362);
            this.staffview.TabIndex = 25;
            this.staffview.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.staffview_CellContentClick);
            // 
            // searchs
            // 
            this.searchs.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchs.Location = new System.Drawing.Point(874, 217);
            this.searchs.Name = "searchs";
            this.searchs.Size = new System.Drawing.Size(210, 32);
            this.searchs.TabIndex = 26;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Impact", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(742, 217);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(122, 25);
            this.label13.TabIndex = 27;
            this.label13.Text = "Enter Position";
            // 
            // delete
            // 
            this.delete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.delete.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.delete.Location = new System.Drawing.Point(698, 654);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(161, 52);
            this.delete.TabIndex = 30;
            this.delete.Text = "DELETE";
            this.delete.UseVisualStyleBackColor = false;
            this.delete.Click += new System.EventHandler(this.delete_Click);
            // 
            // update
            // 
            this.update.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(231)))), ((int)(((byte)(113)))));
            this.update.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.update.Location = new System.Drawing.Point(505, 654);
            this.update.Name = "update";
            this.update.Size = new System.Drawing.Size(161, 52);
            this.update.TabIndex = 29;
            this.update.Text = "UPDATE";
            this.update.UseVisualStyleBackColor = false;
            this.update.Click += new System.EventHandler(this.update_Click);
            // 
            // insert
            // 
            this.insert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(241)))), ((int)(((byte)(189)))));
            this.insert.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.insert.Location = new System.Drawing.Point(305, 654);
            this.insert.Name = "insert";
            this.insert.Size = new System.Drawing.Size(161, 52);
            this.insert.TabIndex = 28;
            this.insert.Text = "INSERT";
            this.insert.UseVisualStyleBackColor = false;
            this.insert.Click += new System.EventHandler(this.insert_Click);
            // 
            // reset
            // 
            this.reset.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(152)))), ((int)(((byte)(228)))));
            this.reset.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reset.Location = new System.Drawing.Point(890, 654);
            this.reset.Name = "reset";
            this.reset.Size = new System.Drawing.Size(161, 52);
            this.reset.TabIndex = 31;
            this.reset.Text = "RESET";
            this.reset.UseVisualStyleBackColor = false;
            this.reset.Click += new System.EventHandler(this.reset_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.ssearch);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.reset);
            this.panel1.Controls.Add(this.delete);
            this.panel1.Controls.Add(this.insert);
            this.panel1.Controls.Add(this.update);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.searchs);
            this.panel1.Controls.Add(this.staffview);
            this.panel1.Controls.Add(this.sdate);
            this.panel1.Controls.Add(this.sfemale);
            this.panel1.Controls.Add(this.smale);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.smobile);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.sposition);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.sid);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.saddress);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.sname);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.slogname);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1186, 719);
            this.panel1.TabIndex = 32;
            // 
            // ssearch
            // 
            this.ssearch.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ssearch.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ssearch.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ssearch.Location = new System.Drawing.Point(1090, 217);
            this.ssearch.Name = "ssearch";
            this.ssearch.Size = new System.Drawing.Size(69, 32);
            this.ssearch.TabIndex = 42;
            this.ssearch.Text = "Search";
            this.ssearch.UseVisualStyleBackColor = false;
            this.ssearch.Click += new System.EventHandler(this.ssearch_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(254, 225);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(67, 28);
            this.label14.TabIndex = 11;
            this.label14.Text = "Name";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(211)))), ((int)(((byte)(246)))));
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.staffClose);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1184, 31);
            this.panel3.TabIndex = 41;
            // 
            // staffClose
            // 
            this.staffClose.BackColor = System.Drawing.Color.Transparent;
            this.staffClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.staffClose.ForeColor = System.Drawing.Color.Transparent;
            this.staffClose.Image = ((System.Drawing.Image)(resources.GetObject("staffClose.Image")));
            this.staffClose.Location = new System.Drawing.Point(1145, 0);
            this.staffClose.Name = "staffClose";
            this.staffClose.Size = new System.Drawing.Size(36, 29);
            this.staffClose.TabIndex = 0;
            this.staffClose.UseVisualStyleBackColor = false;
            this.staffClose.Click += new System.EventHandler(this.staffClose_Click);
            // 
            // Staff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(1186, 719);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Staff";
            this.Text = "Staff";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.staffview)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label slogname;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox sname;
        private System.Windows.Forms.TextBox saddress;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox sid;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox sposition;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox smobile;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.RadioButton smale;
        private System.Windows.Forms.RadioButton sfemale;
        private System.Windows.Forms.DateTimePicker sdate;
        private System.Windows.Forms.DataGridView staffview;
        private System.Windows.Forms.TextBox searchs;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.Button update;
        private System.Windows.Forms.Button insert;
        private System.Windows.Forms.Button reset;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button staffClose;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button ssearch;
    }
}