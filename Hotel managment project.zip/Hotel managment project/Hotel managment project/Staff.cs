﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using static System.Windows.Forms.AxHost;

namespace Hotel_managment_project
{
    public partial class Staff : Form
    {
        private string loggedInUsername;

        string path = @"Data Source=DESKTOP-02CDG87\SQLEXPRESS01;Initial Catalog=hotel_managment;Integrated Security=True;";
        SqlConnection conn;
        SqlCommand cmd;

        string name;
        string address;
        string gender;
        int mobile;
        string id;
        string dob;
        string position;

        public Staff(string username)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            conn = new SqlConnection(path);
            Display();
            loggedInUsername = username;
            DisplayLoggedInUsername();
        }

        private void DisplayLoggedInUsername()
        {
            slogname.Text = loggedInUsername;
        }

        private void staffClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //display staff details
        public void Display()
        {
            try
            {
                conn.Open();
                cmd = new SqlCommand("select * from staff", conn);
                cmd.ExecuteNonQuery();
                conn.Close();
                SqlDataAdapter sd = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sd.Fill(dt);
                staffview.DataSource = dt;


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void insert_Click(object sender, EventArgs e)
        {
            name = sname.Text;
            string mobileStr = smobile.Text.TrimStart('0');
            dob = sdate.Value.ToString("yyyy-MM-dd");
            address = saddress.Text;
            id = sid.Text;
            position = sposition.Text;

            if (smale.Checked)
            {
                gender = "Male";
            }
            else if (sfemale.Checked)
            {
                gender = "Female";
            }

            if (System.Text.RegularExpressions.Regex.IsMatch(name, "[0-9~`!@#$%^&*()-+=|\\{}':;,.<>?]"))
            {
                MessageBox.Show("Name should not contain numbers or symbols.");
                return;
            }

            if (!System.Text.RegularExpressions.Regex.IsMatch(mobileStr, @"^\d{9}$"))
            {
                MessageBox.Show("Mobile number should be a 10-digit number starting with 07.");
                return;
            }


            mobile = Convert.ToInt32(mobileStr);

            // Confirm update
            DialogResult confirmResult = MessageBox.Show(
                "Are you sure you want to Delete this record?",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (confirmResult == DialogResult.Yes)
            {

                try
                {
                    conn.Open();

                    // Check if the ID already exists  
                    using (cmd = new SqlCommand("SELECT COUNT(*) FROM staff WHERE id = @id", conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        int idExists = (int)cmd.ExecuteScalar();

                        if (idExists > 0)
                        {
                            MessageBox.Show("This ID is already registered!");
                            return; // Exit the method if ID exists  
                        }
                    }

                    cmd = new SqlCommand("INSERT INTO staff (name, address, id, gender, birth, mobile, position) VALUES (@name, @address, @id, @gender, @birth, @mobile, @position)", conn);

                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@address", address);
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@gender", gender);
                    cmd.Parameters.AddWithValue("@birth", dob);
                    cmd.Parameters.AddWithValue("@mobile", mobile);
                    cmd.Parameters.AddWithValue("@position", position);

                    cmd.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Registered Successfuly!!");
                    Display();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    conn.Close();
                }
            }
        }

        private void staffview_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = staffview.Rows[e.RowIndex];


                string mobileStr = row.Cells["mobile"].Value.ToString();
                if (int.TryParse(mobileStr.TrimStart('0'), out mobile))
                {
                    sname.Text = row.Cells["name"].Value.ToString();
                    smobile.Text = mobileStr;
                    sdate.Value = (DateTime)row.Cells["birth"].Value;
                    saddress.Text = row.Cells["address"].Value.ToString();
                    sid.Text = row.Cells["id"].Value.ToString();
                    sposition.Text = row.Cells["position"].Value.ToString();

                    if (row.Cells["gender"].Value.ToString() == "Male")
                    {
                        smale.Checked = true;
                        sfemale.Checked = false;
                    }
                    else
                    {
                        sfemale.Checked = true;
                        smale.Checked = false;
                    }
                }
            }
            else
            {
                MessageBox.Show("Invalid cell selected.");

            }
        }

        private void update_Click(object sender, EventArgs e)
        {
            if (staffview.CurrentCell != null && mobile != 0)
            {
                name = sname.Text;
                mobile = Convert.ToInt32(smobile.Text.TrimStart('0'));
                dob = sdate.Value.ToString("yyyy-MM-dd");
                address = saddress.Text;
                id = sid.Text;
                position = sposition.Text;

                if (smale.Checked)
                {
                    gender = "Male";
                }
                else if (sfemale.Checked)
                {
                    gender = "Female";
                }

                // Confirm update
                DialogResult confirmResult = MessageBox.Show(
                    "Are you sure you want to update this record?",
                    "Confirm Update",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question
                );

                if (confirmResult == DialogResult.Yes)
                {
                    try
                    {
                        conn.Open();
                        SqlCommand cmd = new SqlCommand("UPDATE staff SET name = @name, address = @address, gender = @gender, birth = @birth, mobile = @mobile, position = @position WHERE id = @id", conn);
                        cmd.Parameters.AddWithValue("@name", name);
                        cmd.Parameters.AddWithValue("@address", address);
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.Parameters.AddWithValue("@gender", gender);
                        cmd.Parameters.AddWithValue("@birth", dob);
                        cmd.Parameters.AddWithValue("@mobile", mobile);
                        cmd.Parameters.AddWithValue("@position", position);
                        cmd.ExecuteNonQuery();
                        conn.Close();
                        Display();
                        MessageBox.Show("Details Update.");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error updating record: " + ex.Message);
                    }
                }
                else
                {
                    MessageBox.Show("Select a record to update.");
                    conn.Close();
                }
            }
        }

        private void delete_Click(object sender, EventArgs e)
        {
            // Confirm update
            DialogResult confirmResult = MessageBox.Show(
                "Are you sure you want to Delete this record?",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (confirmResult == DialogResult.Yes)
            {
                if (mobile != 0)
                {
                    cmd = new SqlCommand("DELETE FROM staff WHERE id = @id", conn);
                    cmd.Parameters.AddWithValue("@id", id);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();

                    MessageBox.Show("Record Deleted Successfully!");
                    Display();
                }
                else
                {
                    MessageBox.Show("Please Select a Record to Delete");
                    conn.Close();
                }
            }
        }

        private void reset_Click(object sender, EventArgs e)
        {
            sname.Text = "";
            smobile.Text = "";
            sid.Text = "";
            saddress.Text = "";
            sposition.Text = "";
            searchs.Text = " ";
            smale.Checked = false;
            sfemale.Checked = false;
            sdate.Value = DateTime.Now;
            mobile = 0;
        }

        private void ssearch_Click(object sender, EventArgs e)
        {
            string searchId = searchs.Text.Trim(); // Get the customer ID to search  

            if (string.IsNullOrWhiteSpace(searchId))
            {
                MessageBox.Show("Please enter a Staff Position to search.");
                return;
            }

            // Clear previous results first  
            staffview.DataSource = null;
            staffview.Rows.Clear();

            try
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT name, address, id, gender, birth, mobile, position FROM staff WHERE position = @position", conn))
                {
                    cmd.Parameters.AddWithValue("@position", searchId);

                    SqlDataReader reader = cmd.ExecuteReader();
                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);

                    if (dataTable.Rows.Count > 0)
                    {
                        staffview.DataSource = dataTable;
                    }
                    else
                    {
                        MessageBox.Show("Staff member not found!");
                        Display();
                    }
                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error fetching customer details: " + ex.Message);
                conn.Close();
            }

    }
    }
}
