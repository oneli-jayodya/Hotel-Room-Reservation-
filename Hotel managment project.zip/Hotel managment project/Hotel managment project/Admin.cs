﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Reflection;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Hotel_managment_project
{
    public partial class Admin : Form
    {
        string path = @"Data Source=DESKTOP-02CDG87\SQLEXPRESS01;Initial Catalog=hotel_managment;Integrated Security=True;";
        SqlConnection conn;
        SqlCommand cmd;

        private string loggedInUsername;

        string name;
        int mobile;
        string passw;
        string dob;
        string gender;

        public Admin(string username)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            conn = new SqlConnection(path);
            
            //show username on top
            loggedInUsername = username;
            DisplayLoggedInUsername();
        }

        private void DisplayLoggedInUsername()
        {
            adlogname.Text = loggedInUsername;
        }


        //form closing
        private void admClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //display admin details
        public void Display()
        {
            try
            {
                conn.Open();
                cmd = new SqlCommand("select * from admin", conn);
                cmd.ExecuteNonQuery();
                conn.Close();
                SqlDataAdapter sd = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sd.Fill(dt);
                adminview.DataSource = dt;
                

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        //insert admin details
        private void insert_Click(object sender, EventArgs e)
        {
            name = aname.Text;
            string mobileStr = amobile.Text.TrimStart('0'); // Remove leading zeroes for validation
            dob = adate.Value.ToString("yyyy-MM-dd");
            passw = pw.Text;

            if (amale.Checked)
            {
                gender = "Male";
            }
            else if (afemale.Checked)
            {
                gender = "Female";
            }
 
            if (System.Text.RegularExpressions.Regex.IsMatch(name, "[0-9~`!@#$%^&*()-+=|\\{}':;,.<>?]"))
            {
                MessageBox.Show("Name should not contain numbers or symbols.");
                return;
            }

            if (!System.Text.RegularExpressions.Regex.IsMatch(mobileStr, @"^\d{9}$")) 
            {
                MessageBox.Show("Mobile number should be a 10-digit number starting with 07.");
                return;
            }

            mobile = Convert.ToInt32(mobileStr);

            // Confirm update
            DialogResult confirmResult = MessageBox.Show(
                "Are you sure you want to Delete this record?",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (confirmResult == DialogResult.Yes)
            {
                try
                {
                    conn.Open();
                    cmd = new SqlCommand("INSERT INTO admin (username, password, gender, birth, mobile) VALUES (@username, @password, @gender, @birth, @mobile)", conn);

                    cmd.Parameters.AddWithValue("@username", name);
                    cmd.Parameters.AddWithValue("@password", passw);
                    cmd.Parameters.AddWithValue("@gender", gender);
                    cmd.Parameters.AddWithValue("@birth", dob);
                    cmd.Parameters.AddWithValue("@mobile", mobile);

                    cmd.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("You are Registered as an Admin!!");
                    Display();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    conn.Close();
                }
            }
        }

        //select row
        private void adminview_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)  
            {
                DataGridViewRow row = adminview.Rows[e.RowIndex];

                 
                string mobileStr = row.Cells["mobile"].Value.ToString();
                if (int.TryParse(mobileStr.TrimStart('0'), out mobile))  
                {
                    aname.Text = row.Cells["username"].Value.ToString();
                    amobile.Text = mobileStr;  
                    adate.Value = (DateTime)row.Cells["birth"].Value; 
                    pw.Text = row.Cells["password"].Value.ToString();

                    if (row.Cells["gender"].Value.ToString() == "Male")
                    {
                        amale.Checked = true;
                        afemale.Checked = false;
                    }
                    else
                    {
                        afemale.Checked = true;
                        amale.Checked = false;
                    }
                }
            }
            else
            {
                MessageBox.Show("Invalid cell selected.");
            }
        }

        //delete admin details
        private void delete_Click(object sender, EventArgs e)
        {
            // Confirm update
            DialogResult confirmResult = MessageBox.Show(
                "Are you sure you want to Delete this record?",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (confirmResult == DialogResult.Yes)
            {

                if (mobile != 0)
                {
                    cmd = new SqlCommand("DELETE FROM admin WHERE mobile = @mobile", conn);
                    cmd.Parameters.AddWithValue("@mobile", mobile);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();

                    MessageBox.Show("Record Deleted Successfully!");
                    Display();
                }
                else
                {
                    MessageBox.Show("Please Select a Record to Delete");
                    conn.Close();
                }
            }
        }

        //show when load form
        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            Display();
        }

        //reset form
        private void reset_Click(object sender, EventArgs e)
        {
            aname.Text = "";
            amobile.Text = "";
            pw.Text = "";
            amale.Checked = false;
            afemale.Checked = false;
            adate.Value = DateTime.Now;
            mobile = 0;
        }

        //update admin details
        private void update_Click(object sender, EventArgs e)
        {
            if (adminview.CurrentCell != null && mobile != 0)
            {
                name = aname.Text;
                mobile = Convert.ToInt32(amobile.Text.TrimStart('0'));
                dob = adate.Value.ToString("yyyy-MM-dd");
                passw = pw.Text;

                if (amale.Checked)
                {
                    gender = "Male";
                }
                else if (afemale.Checked)
                {
                    gender = "Female";
                }

                // Confirm update
                DialogResult confirmResult = MessageBox.Show(
                    "Are you sure you want to update this record?",
                    "Confirm Update",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question
                );

                if (confirmResult == DialogResult.Yes)
                {

                    try
                    {
                        conn.Open();
                        SqlCommand cmd = new SqlCommand("UPDATE admin SET username = @username, password = @password, gender = @gender, birth = @birth WHERE mobile = @mobile", conn);
                        cmd.Parameters.AddWithValue("@username", name);
                        cmd.Parameters.AddWithValue("@password", passw);
                        cmd.Parameters.AddWithValue("@gender", gender);
                        cmd.Parameters.AddWithValue("@birth", dob);
                        cmd.Parameters.AddWithValue("@mobile", mobile);
                        cmd.ExecuteNonQuery();
                        conn.Close();
                        Display();
                        MessageBox.Show("Details Updated.");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error updating record: " + ex.Message);
                    }
                }
                else
                {
                    MessageBox.Show("Select a record to update.");
                    conn.Close();
                }
            }
        }

        
    }
}
