﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Hotel_managment_project
{
    public partial class Booking : Form
    {
        private string loggedInUsername;

        string path = @"Data Source=DESKTOP-02CDG87\SQLEXPRESS01;Initial Catalog=hotel_managment;Integrated Security=True;";
        SqlConnection conn;
        SqlCommand cmd;

        string bedroom;
        string bcheckin;
        string bcheckout;
        int badult;
        int bchild;
        int night;
        string id;
        string food;
        string room;

        public Booking(string username)
        {
            conn = new SqlConnection(path);
            InitializeComponent();
            Display();
            loggedInUsername = username;
            DisplayLoggedInUsername();
            LoadCustomerNames();
        }

        private void DisplayLoggedInUsername()
        {
            blogname.Text = loggedInUsername;
        }

        //load customer id from customer table
        private void LoadCustomerNames()
        {
            try
            {
                using (conn = new SqlConnection(path))
                {
                    conn.Open();
                    using (cmd = new SqlCommand("SELECT id FROM customer", conn))
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            List<string> customerid = new List<string>();
                            customerid.Add(" ");

                            while (reader.Read())
                            {
                                customerid.Add(reader["id"].ToString());
                            }
                            // Binding data to ComboBox  
                            idcombo.DataSource = customerid;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading customer id: " + ex.Message);
            }
        }

        private void bookClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //display details
        public void Display()
        {
            try
            {
                using (conn = new SqlConnection(path))
                {
                    conn.Open();
                    cmd = new SqlCommand("SELECT * FROM booking", conn);
                    SqlDataAdapter sd = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    sd.Fill(dt);
                    bookview.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }


        //insert details
        private void insertb_Click(object sender, EventArgs e)
        {
            // Retrieve values from ComboBoxes and other fields  
            id = idcombo.SelectedValue.ToString();

            // Validate and convert selections with pre-checks  
            if (!int.TryParse(adult.SelectedItem?.ToString(), out badult))
            {
                MessageBox.Show("Please select a valid number of adults.");
                return;
            }
            if (!int.TryParse(child.SelectedItem?.ToString(), out bchild))
            {
                MessageBox.Show("Please select a valid number of children.");
                return;
            }
            if (!int.TryParse(bnight.Text, out night))
            {
                MessageBox.Show("Please enter a valid number of nights.");
                return;
            }
            if (idcombo.SelectedValue == null)
            {
                MessageBox.Show("Please select a valid ID.");
                return;
            }
            id = idcombo.SelectedValue.ToString();
            if (rooms.SelectedValue == null)
            {
                MessageBox.Show("Please select a valid room.");
                return;
            }

            bedroom = GetSelectedBedroom();
            if (bedroom == null)
            {
                MessageBox.Show("Select bedroom please");
                return;
            }

            room = rooms.Text;
            bcheckin = checkin.Value.ToString("yyyy-MM-dd");
            bcheckout = checkout.Value.ToString("yyyy-MM-dd");

            try
            {
                using (conn = new SqlConnection(path))
                {
                    conn.Open();

                    string checkIdSql = "SELECT COUNT(*) FROM booking WHERE id = @id";
                    using (SqlCommand cmd = new SqlCommand(checkIdSql, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        int idCount = (int)cmd.ExecuteScalar();

                        if (idCount > 0)
                        {
                            MessageBox.Show("This ID has already been used for a booking.");
                            return;
                        }
                    }

                    string sql = "INSERT INTO booking (id, adult, child, night, bedroom, rooms, checkin, checkout) " +
                                 "VALUES (@id, @adult, @child, @night, @bedroom, @room, @checkin, @checkout)";

                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.Parameters.AddWithValue("@adult", badult);
                        cmd.Parameters.AddWithValue("@child", bchild);
                        cmd.Parameters.AddWithValue("@night", night);
                        cmd.Parameters.AddWithValue("@bedroom", bedroom);
                        cmd.Parameters.AddWithValue("@room", room);
                        cmd.Parameters.AddWithValue("@checkin", bcheckin);
                        cmd.Parameters.AddWithValue("@checkout", bcheckout);
                        cmd.ExecuteNonQuery();
                    }
                    string updateRoomSql = "UPDATE room SET IsAvailable = 0 WHERE roomNo = @roomNo";
                    using (SqlCommand cmd = new SqlCommand(updateRoomSql, conn))
                    {
                        cmd.Parameters.AddWithValue("@roomNo", room);
                        cmd.ExecuteNonQuery();
                    }

                    conn.Close();
                }

                MessageBox.Show("Booking created successfully.");
                Display();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error inserting booking: " + ex.Message);
            }
        }

        private string GetSelectedBedroom()
        {
            if (single.Checked) return "Single";
            if (doubleroom.Checked) return "Double";
            if (family.Checked) return "Family";
            return null;        
        }


        private void single_CheckedChanged(object sender, EventArgs e)
        {
            if (single.Checked)
            {
                LoadRooms("single"); // Load only single rooms  
            }
        }

        private void doubleroom_CheckedChanged(object sender, EventArgs e)
        {
            if (doubleroom.Checked)
            {
                LoadRooms("double"); // Load only double rooms  
            }
        }

        private void family_CheckedChanged(object sender, EventArgs e)
        {
            if (family.Checked)
            {
                LoadRooms("family"); // Load only family rooms  
            }
        }

        // Method to load rooms based on the selected room type  
        private void LoadRooms(string roomtype)
        {
            string query = "";

            switch (roomtype)
            {
                case "family":
                    query = "SELECT roomid, roomNo FROM room WHERE roomtype = 'family' AND IsAvailable = 1";
                    break;
                case "double":
                    query = "SELECT roomid, roomNo FROM room WHERE roomtype = 'double' AND IsAvailable = 1";
                    break;
                case "single":
                    query = "SELECT roomid, roomNo FROM room WHERE roomtype = 'single' AND IsAvailable = 1";
                    break;
                default:
                    return;
            }

            using (SqlConnection conn = new SqlConnection(path))
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                DataTable roomsTable = new DataTable();
                roomsTable.Load(reader);

                rooms.DataSource = null;  // Clear previous data  
                rooms.DataSource = roomsTable;
                rooms.DisplayMember = "roomNo";   // Display room numbers
                rooms.ValueMember = "roomid";     // Use room IDs as the value
            }
        }

        //row select
        private void bookview_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = bookview.Rows[e.RowIndex];
  
                if (row.Cells["id"].Value != null)
                { 
                    string idStr = row.Cells["id"].Value.ToString();
                    id = idStr;  
                    adult.SelectedItem = row.Cells["adult"].Value?.ToString();
                    child.SelectedItem = row.Cells["child"].Value?.ToString();
                    bnight.Text = row.Cells["night"].Value?.ToString();

                    // Set bedroom radio buttons based on the selected row  
                    string bedroom = row.Cells["bedroom"].Value?.ToString();
                    single.Checked = bedroom == "Single";
                    doubleroom.Checked = bedroom == "Double";
                    family.Checked = bedroom == "Family";

                    // Populate the rooms and dates  
                    rooms.Text = row.Cells["rooms"].Value?.ToString();
                    checkin.Value = DateTime.TryParse(row.Cells["checkin"].Value?.ToString(), out DateTime checkinDate) ? checkinDate : DateTime.Now;
                    checkout.Value = DateTime.TryParse(row.Cells["checkout"].Value?.ToString(), out DateTime checkoutDate) ? checkoutDate : DateTime.Now;
                }
                else
                {
                    MessageBox.Show("ID value is null. Please select a valid row.", "Selection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void deleteb_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(id))
            {
                string roomNo = string.Empty;

                // Fetch the selected row based on the id
                foreach (DataGridViewRow row in bookview.Rows)
                {
                    if (row.Cells["id"].Value.ToString() == id)
                    {
                        roomNo = row.Cells["rooms"].Value.ToString();
                        break;
                    }
                }

                // Confirm update
                DialogResult confirmResult = MessageBox.Show(
                    "Are you sure you want to Delete this record?",
                    "Confirm Delete",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question
                );

                if (confirmResult == DialogResult.Yes)
                {
                    try
                    {
                        using (conn = new SqlConnection(path))
                        {
                            conn.Open();

                            string deleteBookingSql = "DELETE FROM booking WHERE id = @id";
                            using (SqlCommand cmd = new SqlCommand(deleteBookingSql, conn))
                            {
                                cmd.Parameters.AddWithValue("@id", id);
                                cmd.ExecuteNonQuery();
                            }

                            if (!string.IsNullOrEmpty(roomNo))
                            {
                                string updateRoomSql = "UPDATE room SET IsAvailable = 1 WHERE roomNo = @roomNo";
                                using (SqlCommand cmd = new SqlCommand(updateRoomSql, conn))
                                {
                                    cmd.Parameters.AddWithValue("@roomNo", roomNo);
                                    cmd.ExecuteNonQuery();
                                }
                            }

                            conn.Close();
                        }

                        MessageBox.Show("Booking deleted successfully.");
                        Display();
                        LoadRooms(GetSelectedBedroom().ToLower());  // Reload rooms after deletion
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error deleting booking: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a valid booking to delete.");
            }
        }


        private void updateb_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(id))
            {
                // Gather data from form controls  
                string adultCount = adult.SelectedItem?.ToString();
                string childCount = child.SelectedItem?.ToString();
                string nightCount = bnight.Text;
                string roomType = single.Checked ? "Single" : doubleroom.Checked ? "Double" : "Family";
                string roomCount = rooms.Text;
                string checkinDate = checkin.Value.ToString("yyyy-MM-dd");
                string checkoutDate = checkout.Value.ToString("yyyy-MM-dd");

                // Validate inputs
                if (string.IsNullOrEmpty(adultCount) || string.IsNullOrEmpty(childCount) || string.IsNullOrEmpty(nightCount) || string.IsNullOrEmpty(roomCount))
                {
                    MessageBox.Show("Please fill all required fields.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Confirm update
                DialogResult confirmResult = MessageBox.Show(
                    "Are you sure you want to update this record?",
                    "Confirm Update",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question
                );

                if (confirmResult == DialogResult.Yes)
                {
                    using (conn = new SqlConnection(path))
                    {
                        string updateQuery = "UPDATE booking SET adult = @adult, child = @child, night = @night, bedroom = @bedroom, rooms = @rooms, checkin = @checkin, checkout = @checkout WHERE id = @id";

                        using (SqlCommand cmd = new SqlCommand(updateQuery, conn))
                        {

                            cmd.Parameters.AddWithValue("@adult", adultCount);
                            cmd.Parameters.AddWithValue("@child", childCount);
                            cmd.Parameters.AddWithValue("@night", nightCount);
                            cmd.Parameters.AddWithValue("@bedroom", roomType);
                            cmd.Parameters.AddWithValue("@rooms", roomCount);
                            cmd.Parameters.AddWithValue("@checkin", checkinDate);
                            cmd.Parameters.AddWithValue("@checkout", checkoutDate);
                            cmd.Parameters.AddWithValue("@id", id);

                            try
                            {
                                conn.Open();
                                int rowsAffected = cmd.ExecuteNonQuery();

                                if (rowsAffected > 0)
                                {
                                    MessageBox.Show("Record updated successfully.", "Update Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    Display();
                                }
                                else
                                {
                                    MessageBox.Show("No record found for the given ID.", "Update Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                }
                            }
                            catch (SqlException ex)
                            {
                                MessageBox.Show("An error occurred while updating the record: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a record to update.", "Update Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void resetb_Click(object sender, EventArgs e)
        {
            bnight.Text = string.Empty;
            // Reset ComboBoxes
            adult.SelectedIndex = -1;
            child.SelectedIndex = -1;
            // Uncheck all radio buttons
            single.Checked = false;
            doubleroom.Checked = false;
            family.Checked = false;
            // Clear room selection
            rooms.SelectedIndex = -1;
            rooms.Text = string.Empty;
            // Reset date pickers to current date
            checkin.Value = DateTime.Now;
            checkout.Value = DateTime.Now;
            id = string.Empty;  // Clear the stored ID

            MessageBox.Show("Form has been reset.", "Reset", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void booksearch_Click(object sender, EventArgs e)
        {
            string searchId = searchb.Text; 

            if (string.IsNullOrWhiteSpace(searchId))
            {
                MessageBox.Show("Please enter a customer ID to search.");
                return;
            }

            // Clear previous results first  
            bookview.DataSource = null;
            bookview.Rows.Clear();

            try
            {
                using (conn = new SqlConnection(path))
                {
                    conn.Open();
                    using (cmd = new SqlCommand("SELECT * FROM booking WHERE id = @id", conn))
                    {
                        cmd.Parameters.AddWithValue("@id", searchId);

                        SqlDataReader reader = cmd.ExecuteReader();
                        DataTable dataTable = new DataTable();
                        dataTable.Load(reader);

                        if (dataTable.Rows.Count > 0)
                        {
                            bookview.DataSource = dataTable;
                        }
                        else
                        {
                            MessageBox.Show("Booking not found!");
                            Display();
                        }
                        conn.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error fetching booking details: " + ex.Message);
                conn.Close();
            }

        }
    }
}
    