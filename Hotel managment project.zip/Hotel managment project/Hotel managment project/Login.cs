﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Hotel_managment_project
{
    public partial class Login : Form
    {
        string path = @"Data Source=DESKTOP-02CDG87\SQLEXPRESS01;Initial Catalog=hotel_managment;Integrated Security=True;";
        SqlConnection conn;
        SqlCommand cmd;

        string username;
        string pw;

        public Login()
        {
            InitializeComponent();
            //center form
            this.StartPosition = FormStartPosition.CenterScreen;
            conn = new SqlConnection();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void logbtn_Click(object sender, EventArgs e)
        {
            username = uname.Text;
            pw = password.Text;

            try
            {
                using (conn = new SqlConnection(path))
                {
                    conn.Open();

                    string query = "SELECT * FROM admin WHERE username = @username AND password = @password";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        // Use parameters to avoid SQL Injection
                        cmd.Parameters.AddWithValue("@username", username);
                        cmd.Parameters.AddWithValue("@password", pw);

                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        if (dt.Rows.Count > 0)
                        {
                            MessageBox.Show("Login successful ", "Successful");
                            this.Hide();
                            Dashboard dash = new Dashboard(username);
                            dash.ShowDialog();
                        }
                        else
                        {
                            MessageBox.Show("Invalid Username or Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            uname.Clear();
                            password.Clear();
                        }
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                // Catch SQL exceptions
                MessageBox.Show($"SQL Error: {sqlEx.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                // Catch other exceptions
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }


        private void log_close(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
