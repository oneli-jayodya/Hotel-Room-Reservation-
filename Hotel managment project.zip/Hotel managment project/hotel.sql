create database hotel_managment;

use hotel_managment;

create table admin(
	username varchar(20),
	password varchar(8),
	gender varchar(10),
	birth Date,
	mobile int
);

select * from admin;

insert into admin values ('oneli','ona2002','Female','1/15/2002','0756174242');

create table customer(
	name varchar(20),
	address varchar(50),
	id varchar(12),
	gender varchar(8),
	birth Date,
	mobile int
);

select * from customer;

create table staff(
	name varchar(20),
	address varchar(50),
	id varchar(12),
	gender varchar(8),
	birth Date,
	mobile int,
	position varchar(30)
);

select * from staff;

create table booking(
	id varchar(13),
	adult int,
	child int,
	night int,
	bedroom varchar(7),
	rooms varchar(10),
	checkin date,
	checkout date,
);

select * from booking;

create table room(
	roomid int,
	roomNo int,
	roomtype varchar(10),
	IsAvailable int
);

insert into room values ('2','110','single','1'), ('3','120','single','1'),
 ('4','130','single','1'),
('5','140','single','1'),
 ('6','150','double','1'),
 ('7','160','double','1'),
 ('8','170','double','1'),
 ('9','180','double','1'),
 ('10','190','family','1'),
 ('11','200','family','1'),
 ('12','210','family','1'),
 ('13','220','family','1'),
 ('14','230','family','1'),
 ('15','240','single','1'),
 ('16','250','single','1'),
 ('17','260','family','1'),
 ('18','270','family','1'),
 ('19','280','double','1'),
 ('20','290','double','1');

select * from room;

SELECT 
    SUM(adult) AS TotalAdults,
    SUM(child) AS TotalChildren,
    COUNT(*) AS TotalBookings
FROM 
    booking;

	select * from customer;